package com.example.donproject.service;

import com.example.donproject.dto.DonDTO;
import com.example.donproject.model.Campagne;
import com.example.donproject.model.Don;
import com.example.donproject.repository.CampagneRepository;
import com.example.donproject.repository.DonRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class DonService {

    private final DonRepository donRepository;
    private final CampagneRepository campagneRepository;

    public DonService(DonRepository donRepository, CampagneRepository campagneRepository) {
        this.donRepository = donRepository;
        this.campagneRepository = campagneRepository;
    }

    public DonDTO enregistrerDon(Long campagneId, DonDTO dto) {
        Campagne campagne = campagneRepository.findById(campagneId)
                .orElseThrow(() -> new RuntimeException("Campagne non trouvée"));

        Don don = new Don();
        don.setCampagne(campagne);
        don.setNomDonateur(dto.getNomDonateur());
        don.setMontant(dto.getMontant());
        don.setDate(LocalDate.now());

        Don saved = donRepository.save(don);

        dto.setId(saved.getId());
        dto.setDate(saved.getDate());
        dto.setNomCampagne(campagne.getNom());

        return dto;
    }
}

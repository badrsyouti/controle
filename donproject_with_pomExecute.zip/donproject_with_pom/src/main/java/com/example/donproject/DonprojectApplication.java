package com.example.donproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonprojectApplication {
    public static void main(String[] args) {
        SpringApplication.run(DonprojectApplication.class, args);
    }
}

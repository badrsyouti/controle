package com.example.donproject.controller;

import com.example.donproject.model.CampagneResume;
import com.example.donproject.service.CampagneService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/campagnes")
public class CampagneController {
    private final CampagneService campagneService;

    public CampagneController(CampagneService campagneService) {
        this.campagneService = campagneService;
    }

    @GetMapping("/actives")
    public List<CampagneResume> getActives() {
        return campagneService.getCampagnesActives();
    }
}
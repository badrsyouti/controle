package com.example.donproject.model;

import java.math.BigDecimal;

public interface CampagneResume {
    Long getId();
    String getNom();
    BigDecimal getObjectifMontant();
}
package com.example.donproject.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public class DonDTO {
    private Long id;
    private String nomCampagne;

    @NotBlank
    private String nomDonateur;

    @DecimalMin("0.01")
    private BigDecimal montant;

    private LocalDate date;

    // Getters et Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNomCampagne() { return nomCampagne; }
    public void setNomCampagne(String nomCampagne) { this.nomCampagne = nomCampagne; }

    public String getNomDonateur() { return nomDonateur; }
    public void setNomDonateur(String nomDonateur) { this.nomDonateur = nomDonateur; }

    public BigDecimal getMontant() { return montant; }
    public void setMontant(BigDecimal montant) { this.montant = montant; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
}

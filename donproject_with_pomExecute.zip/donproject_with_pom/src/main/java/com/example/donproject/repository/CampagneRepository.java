package com.example.donproject.repository;

import com.example.donproject.model.Campagne;
import com.example.donproject.model.CampagneResume;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CampagneRepository extends JpaRepository<Campagne, Long> {
    List<CampagneResume> findByDateFinAfter(LocalDate date);
}
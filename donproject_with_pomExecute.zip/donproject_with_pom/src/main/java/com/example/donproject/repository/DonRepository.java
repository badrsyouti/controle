package com.example.donproject.repository;

import com.example.donproject.model.Don;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonRepository extends JpaRepository<Don, Long> {
}

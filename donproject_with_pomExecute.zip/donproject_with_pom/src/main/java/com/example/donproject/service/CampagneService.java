package com.example.donproject.service;

import com.example.donproject.model.CampagneResume;
import com.example.donproject.repository.CampagneRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class CampagneService {
    private final CampagneRepository campagneRepository;

    public CampagneService(CampagneRepository campagneRepository) {
        this.campagneRepository = campagneRepository;
    }

    public List<CampagneResume> getCampagnesActives() {
        return campagneRepository.findByDateFinAfter(LocalDate.now());
    }
}
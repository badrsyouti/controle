package com.example.donproject.controller;

import com.example.donproject.dto.DonDTO;
import com.example.donproject.service.DonService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/campagnes")
public class DonController {
    private final DonService donService;

    public DonController(DonService donService) {
        this.donService = donService;
    }

    @PostMapping("/{id}/dons")
    public ResponseEntity<DonDTO> enregistrerDon(@PathVariable Long id, @RequestBody @Valid DonDTO dto) {
        DonDTO saved = donService.enregistrerDon(id, dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }
}